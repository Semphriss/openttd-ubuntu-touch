﻿-----------------------------
       NightGFX Readme
-----------------------------

NightGFX is a 32bpp base graphics set for OpenTTD. It is a modified version 
of the OpenGFX 8bpp base graphics set, freely available under the terms of 
the GNU General Public License version 2. For more information about OpenGFX, 
including original author credits, please visit the project home page: 

https://github.com/OpenTTD/OpenGFX

-----------------------------
        Compatibility
-----------------------------

This base graphics set is only compatible with OpenTTD 1.2.0 or newer. 

-----------------------------
         How To Use
-----------------------------

NightGFX works just like any other base graphics set, simply download to the 
correct location (or better yet, use the in-game content downloader) then select
NightGFX under the game options screen from the main menu. Once you exit the 
menu, the visual style of the game will immediately change to night-time. It is 
now ready to use, both in single player and multiplayer.

BUT BEWARE! Due to the drastic visual difference between this set and conventional 
'day time' graphics, virtually no existing NewGRFs can be used with NightGFX! 
If you try to play a game with NewGRFs which provide graphics, they will almost 
certainly clash horribly against the darkness, rendering the game almost 
unplayable. Keep this in mind especially when joining a multiplayer server!

-----------------------------
       Day/Night Mode?
-----------------------------

There is not, and likely never will be a way to make OpenTTD change automatically 
from day to night. With OpenGFX and NightGFX installed however, you can achieve 
something similar.

Because this is a base graphics set, it is not stored in the savegame. This allows 
you to switch from day to night while playing the same game. When you're ready for 
a change, simply save and exit to the main menu and switch base graphics sets 
again. 

--------------

This assumes you are not playing with any NewGRFs of course, which ARE stored in 
the savegame and thus can't be changed. Although it is possible for NewGRFs to 
detect the difference between NightGFX and OpenGFX to change graphics accordingly, 
there is no guarantee they will do so. For example, as of this release 
(April 2021) only two known NewGRFs currently support NightGFX, so please check for 
support when using NightGFX with NewGRFs (especially in multiplayer!) to avoid 
ugly mismatches.

-----------------------------
         Known Issues
-----------------------------

 - This set does not provide 2x zoom GUI sprites. These may be added later, but 
for now the 1x sprites will work.
 
 - All lights look the same. These will hopefully be improved in the future.

 - Lights don't illuminate their surroundings. Sorry, OpenTTD can't do that ;)
I can kind of fake it in some places, but things like headlights on vehicles will 
never be able to 'project' light onto other objects.

-----------------------------
      License & Credits
-----------------------------

All sprites were originally drawn by the authors of OpenGFX (see above); 
Night conversion done by Andrew350. 

Both projects are licensed under the terms of the GNU General Public License 
version 2, which should be included with this NewGRF. See license.txt for details. 
If for some strange reason you didn't recieve a copy of the license with this GRF, 
it can be found online here: 
http://www.gnu.org/licenses/gpl-2.0.txt

For information about obtaining the source of NightGFX, please visit this link:

http://www.tt-forums.net/viewtopic.php?f=67&t=69607

------------------------------------
Bug Reports, Comments, & Suggestions
------------------------------------

If you're having problems, notice a bug, or just want to get a hold of me, you can 
post in the release topic online at tt-forums or PM me, Andrew350:

http://www.tt-forums.net/viewtopic.php?f=67&t=69607

Thanks for playing, enjoy!

